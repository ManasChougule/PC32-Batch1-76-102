package com.cdac.ThirdSpring.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"com.cdac.ThirdSpring.components"})
public class ApplicationConfig {

}
